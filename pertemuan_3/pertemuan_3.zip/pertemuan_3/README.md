# Pertemuan 3
- Prepare Dataset
    - Convert Video to Image dataset
    - Annotate Image Dataset using `LabelImg`
    - Split dataset
- Training Tensorflow model Faster R-CNN Inception V2 in Google Colab
- Deploy model to Jetson Nano <br>
![](resource/diag.png)
____
# 1. Prepare Dataset
- Take a video for the object to be detected. `One video` for `one data class`.<br>
![](resource/ironman.gif)
- Clone [ObjectDetection-Tensorflow](https://github.com/Muhammad-Yunus/ObjectDetection-Tensorflow) repository from Github,
- Convert Video to Image using `dataset_builder.ipynb` in cloned `ObjectDetection-Tensorflow` repo.
- Download & Install [LabelImg](https://github.com/tzutalin/labelImg) 
- Annotate Dataset using LabelImg, <br>
![](resource/annotate_image.gif)
- Split dataset (20% for test dataset, 80% for training dataset) using `dataset_builder.ipynb` in cloned `ObjectDetection-Tensorflow` repo.
___
# 2. Training Tensorflow model Faster R-CNN Inception V2 in Google Colab
- Open [Google Colab](https://colab.research.google.com/notebooks/intro.ipynb#recent=true)
- Upload `Faster_R_CNN_Training_using_Custom_Dataset.ipynb` in cloned `ObjectDetection-Tensorflow` repo to Colab.
![](resource/colab-upload.png)
- Follow the step in uploaded notebook 
- Download `inference_graph.zip` from colab to local computer
- Detection Result : <br>
    <p float="left">
    <img src="resource/batman.png" width="300" />
    <img src="resource/ironman.png" width="300" /> 
    </p>
- Evaluation report :
    - mAP : 100% (0.5IOU)
    ![](resource/eval.png)
___
# 3. Deploy model to Jetson Nano
- extract `inference_graph.zip` in local computer
- copy `frozen_inference_graph.pb` and `faster_rcnn_inception_v2_custom_dataset.pbtxt` from extracted `inference_graph.zip` folder to  `pertemuan_3/model/` folder in Jetson Nano.
- copy `object-detection.json` file created in step one (prepare dataset - [ObjectDetection-Tensorflow](https://github.com/Muhammad-Yunus/ObjectDetection-Tensorflow)) to `pertemuan_3/` folder in Jetson Nano.
- run `faster_r-cnn_flask_async.py`,
```
python3 faster_r-cnn_flask_async.py
```
- open result in browser (local computer) with url `http://<jetson nano IP>:5000`
- Result,<br>
![](resource/live-stream.gif)
___
<br><br>
## **[NOTE!]**
- If you wish to use a `different model` you can find the configurations tested in OpenCV listed below.
    <table role="table">
    <thead>
    <tr>
    <th>Model</th>
    <th>Version</th>
    <th></th>
    <th></th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td>MobileNet-SSD v1</td>
    <td>2017_11_17</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/ssd_mobilenet_v1_coco_2017_11_17.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/ssd_mobilenet_v1_coco_2017_11_17.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>MobileNet-SSD v1 PPN</td>
    <td>2018_07_03</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/ssd_mobilenet_v1_ppn_shared_box_predictor_300x300_coco14_sync_2018_07_03.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/ssd_mobilenet_v1_ppn_coco.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>MobileNet-SSD v2</td>
    <td>2018_03_29</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/ssd_mobilenet_v2_coco_2018_03_29.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/ssd_mobilenet_v2_coco_2018_03_29.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>Inception-SSD v2</td>
    <td>2017_11_17</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/ssd_inception_v2_coco_2017_11_17.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/ssd_inception_v2_coco_2017_11_17.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>MobileNet-SSD v3 (see <a href="https://github.com/opencv/opencv/pull/16760">#16760</a>)</td>
    <td>2020_01_14</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/ssd_mobilenet_v3_large_coco_2020_01_14.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://gist.github.com/dkurt/54a8e8b51beb3bd3f770b79e56927bd7">config</a></td>
    </tr>
    <tr>
    <td>Faster-RCNN Inception v2</td>
    <td>2018_01_28</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/faster_rcnn_inception_v2_coco_2018_01_28.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/faster_rcnn_inception_v2_coco_2018_01_28.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>Faster-RCNN ResNet-50</td>
    <td>2018_01_28</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/faster_rcnn_resnet50_coco_2018_01_28.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/faster_rcnn_resnet50_coco_2018_01_28.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>Mask-RCNN Inception v2</td>
    <td>2018_01_28</td>
    <td><a href="http://download.tensorflow.org/models/object_detection/mask_rcnn_inception_v2_coco_2018_01_28.tar.gz" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/mask_rcnn_inception_v2_coco_2018_01_28.pbtxt">config</a></td>
    </tr>
    <tr>
    <td>EfficientDet-D0 (see <a href="https://github.com/opencv/opencv/pull/17384">#17384</a>)</td>
    <td></td>
    <td><a href="https://www.dropbox.com/s/9mqp99fd2tpuqn6/efficientdet-d0.pb?dl=1" rel="nofollow">weights</a></td>
    <td><a href="https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/efficientdet-d0.pbtxt">config</a></td>
    </tr>
    </tbody>
    </table>
